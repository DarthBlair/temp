:orphan:

deprecated-config
=================

``DOCUMENTATION`` config is scheduled for removal
